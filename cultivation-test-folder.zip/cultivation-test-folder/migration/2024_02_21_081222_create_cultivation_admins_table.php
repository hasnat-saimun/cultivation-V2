<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cultivation_admins', function (Blueprint $table) {
            $table->id();
            $table->string('adminName')->nullable();
            $table->string('adminUser')->nullable();
            $table->string('userType')->nullable();
            $table->string('loginPassword')->nullable();
            $table->string('adminMobile')->nullable();
            $table->string('adminMail')->nullable();
            $table->string('accessClass')->nullable();
            $table->string('accessSubject')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cultivation_admins');
    }
};
